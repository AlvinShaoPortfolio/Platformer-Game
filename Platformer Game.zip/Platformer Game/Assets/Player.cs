using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public int maxHealth = 20;
    int currentHealth;

    void Start()
    {
        currentHealth = maxHealth;
    }

   public void TakeDamage(int damage)
   {
        currentHealth -= damage;

        if(currentHealth <=0)
        {
            Die();
        }
   }

    void Die()
    {
        GetComponent<Collider2D>().enabled = false;
		GetComponent<SpriteRenderer>().enabled = false;
        GetComponent<CharacterController2D>().enabled = false;
        GetComponent<CircleCollider2D>().enabled = false;
        GetComponent<PlayerMovement>().enabled = false;
        this.enabled = false;
    }


}
